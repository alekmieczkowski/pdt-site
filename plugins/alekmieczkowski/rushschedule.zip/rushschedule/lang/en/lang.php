<?php return [
    'plugin' => [
        'name' => 'Rush Schedule',
        'description' => ''
    ]
];